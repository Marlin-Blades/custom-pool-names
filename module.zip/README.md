# custom-pool-names
Modifying the Cypher System pool names for FoundryVTT
